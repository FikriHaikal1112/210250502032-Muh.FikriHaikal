/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lampulalulintas;

import java.util.Scanner;
public class If_Kondisi_2 {
    public static void main(String[] args) {
 /* Warning light = lampu peringatan hati hati bagi pengendara biasanya lampu tersebut berada 
    di daerah yang sering terjadi kerusakan jalan dan dalam tes ini lampu tersebut berkedip 
    sebagai kode mengenai kondisi jalan tersebut        
 */ 
        
        Scanner in = new Scanner(System.in);
        
        System.out.println("pilih salah satu angka untuk menentukan kedipan warning light = ");
        int lampu ;
        
        lampu = in.nextInt(); 
        
        if ( lampu == 1 ){
            System.out.println("Kurangi Kecepatan");
            
        } else if (lampu == 2){
            System.out.println("Hati hati ada perbaikan Jalanan");
        
        }else { 
            System.out.println("Mohon Kurangi Kecepatan sering terjadi kerusakan jalan");
        }        
    }
}
