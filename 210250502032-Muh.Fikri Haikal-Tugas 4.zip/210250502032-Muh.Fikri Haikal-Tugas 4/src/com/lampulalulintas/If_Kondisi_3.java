/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lampulalulintas;

import java.util.Scanner;

public class If_Kondisi_3 {
    public static void main(String[] args) {
        
        // Traffic Light Pada Umumnya 
        
        Scanner in = new Scanner(System.in);
        System.out.println("Warna Lampu = ");
        String lampu ;
        
        lampu = in.nextLine(); 
        
        if ("merah".equals(lampu)){
            System.out.println("Berhenti");
        } else if ("kuning".equals(lampu)){
            System.out.println("Bersiap siap ");
        } else if ("hijau".equals(lampu)){
            System.out.println("Selamat Jalan"); 
        }else { 
            System.out.println("Lampu Rusak Mohon Hati-hati saat berkendara ");
        }        
    }
}
