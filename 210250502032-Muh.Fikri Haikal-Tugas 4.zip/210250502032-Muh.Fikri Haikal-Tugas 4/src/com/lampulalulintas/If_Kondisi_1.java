/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.lampulalulintas;

import java.util.Scanner;
public class If_Kondisi_1 {
    public static void main(String[] args) {
        
        /* Pelican Crossing = Lampu lalu lintas yang diperuntukkan bagi pejalan kaki 
        Pelican crossing di gunakan bagi pejalan kaki yang ingin menyeberang 
        
        dengan menekan tombol merah ,maka lampu lalu lintas akan berubah menjadi 
        berwarna merah dan lampu hijau menyala untuk lampu pelican crossing 
        agar pejalan kaki dapat berjalan menyeberangi jalanan tersebut 
        */
        Scanner in = new Scanner(System.in);
        
        System.out.println("Warna Lampu = ");
        String lampu ;
        
        lampu = in.nextLine(); 
        
        if ("hijau".equals(lampu)){
            System.out.println("silahkan jalan");
        } else { 
            System.out.println("Mohon Tekan Tombol Merah Jika Ingin Menyeberang jalan");
        }        
    }
}
